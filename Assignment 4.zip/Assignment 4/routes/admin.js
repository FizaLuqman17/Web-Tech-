// ================================================
// routes/admin.js — Admin Panel Routes (Assignment 4)
// ================================================
// Provides CRUD operations for products + image upload via Multer.

const express = require("express");
const router  = express.Router();
const path    = require("path");
const fs      = require("fs");
const multer  = require("multer");
const Product = require("../models/Product");

// ── Body parsing for plain (non-file) POST forms ──
// We mount these locally on the admin router so the rest of the app is unaffected.
router.use(express.urlencoded({ extended: true }));
router.use(express.json());

// ── Simple placeholder auth (per assignment) ──────
// Replace `next()` with real auth later if needed.
function adminAuth(req, res, next) {
    next();
}
router.use(adminAuth);

// ── Multer Configuration ──────────────────────────
// Make sure the uploads folder exists
const uploadDir = path.join(__dirname, "..", "public", "uploads");
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        // Format: timestamp-originalname (spaces removed for safety)
        const safeName = file.originalname.replace(/\s+/g, "-");
        cb(null, Date.now() + "-" + safeName);
    }
});

// Accept only image mimetypes
function imageFileFilter(req, file, cb) {
    if (file.mimetype && file.mimetype.startsWith("image/")) {
        cb(null, true);
    } else {
        cb(null, false); // silently reject; we'll handle validation in the route
    }
}

const upload = multer({
    storage: storage,
    fileFilter: imageFileFilter,
    limits: { fileSize: 5 * 1024 * 1024 } // 5 MB
});

// ── Validation Helper ─────────────────────────────
// Returns an array of error strings. Empty array = valid.
function validateProductFields(body, { imageRequired }) {
    const errors = [];

    const name     = (body.name     || "").trim();
    const category = (body.category || "").trim();
    const price    = body.price;
    const rating   = body.rating;
    const stock    = body.stock;

    if (!name)                                   errors.push("Name is required.");
    if (!category)                               errors.push("Category is required.");

    if (price === undefined || price === "")     errors.push("Price is required.");
    else if (isNaN(Number(price)))               errors.push("Price must be a number.");
    else if (Number(price) < 0)                  errors.push("Price cannot be negative.");

    if (rating === undefined || rating === "")   errors.push("Rating is required.");
    else if (isNaN(Number(rating)))              errors.push("Rating must be a number.");
    else if (Number(rating) < 0 || Number(rating) > 5)
                                                 errors.push("Rating must be between 0 and 5.");

    if (stock === undefined || stock === "")     errors.push("Stock is required.");
    else if (isNaN(Number(stock)))               errors.push("Stock must be a number.");
    else if (Number(stock) < 0)                  errors.push("Stock cannot be negative.");

    return errors;
}

// =================================================
// GET /admin — Dashboard with product table
// =================================================
router.get("/", async (req, res) => {
    try {
        const products = await Product.find().sort({ _id: -1 });
        res.render("admin/dashboard", {
            products,
            totalProducts: products.length
        });
    } catch (error) {
        console.log("Admin Dashboard Error:", error);
        res.status(500).send("Server Error loading admin dashboard");
    }
});

// =================================================
// GET /admin/products/new — Show "Add Product" form
// =================================================
router.get("/products/new", (req, res) => {
    res.render("admin/new-product", {
        errors: [],
        formData: { name: "", price: "", category: "", rating: "", stock: "" }
    });
});

// =================================================
// POST /admin/products — Create new product
// =================================================
router.post("/products", upload.single("image"), async (req, res) => {
    try {
        const errors = validateProductFields(req.body, { imageRequired: true });

        // Image is required when creating
        if (!req.file) {
            errors.push("Product image is required (must be a valid image file).");
        }

        if (errors.length > 0) {
            // If a file was actually uploaded but other fields failed, remove the orphan
            if (req.file) {
                fs.unlink(path.join(uploadDir, req.file.filename), () => {});
            }
            return res.status(400).render("admin/new-product", {
                errors,
                formData: req.body
            });
        }

        const newProduct = new Product({
            name:     req.body.name.trim(),
            price:    Number(req.body.price),
            category: req.body.category.trim(),
            rating:   Number(req.body.rating),
            stock:    Number(req.body.stock),
            image:    "/uploads/" + req.file.filename
        });

        await newProduct.save();
        res.redirect("/admin");
    } catch (error) {
        console.log("Create Product Error:", error);
        res.status(500).render("admin/new-product", {
            errors: ["Server error while saving product. Please try again."],
            formData: req.body || {}
        });
    }
});

// =================================================
// GET /admin/products/:id/edit — Show edit form
// =================================================
router.get("/products/:id/edit", async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).send("Product not found");
        }
        res.render("admin/edit-product", {
            product,
            errors: []
        });
    } catch (error) {
        console.log("Edit Form Error:", error);
        res.status(500).send("Server error loading edit form");
    }
});

// =================================================
// POST /admin/products/:id — Update existing product
// =================================================
router.post("/products/:id", upload.single("image"), async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            // Cleanup orphan file if any
            if (req.file) fs.unlink(path.join(uploadDir, req.file.filename), () => {});
            return res.status(404).send("Product not found");
        }

        const errors = validateProductFields(req.body, { imageRequired: false });

        if (errors.length > 0) {
            if (req.file) fs.unlink(path.join(uploadDir, req.file.filename), () => {});
            // Re-render edit page with current product (merge submitted values for UX)
            product.name     = req.body.name     || product.name;
            product.price    = req.body.price    || product.price;
            product.category = req.body.category || product.category;
            product.rating   = req.body.rating   || product.rating;
            product.stock    = req.body.stock    || product.stock;
            return res.status(400).render("admin/edit-product", { product, errors });
        }

        product.name     = req.body.name.trim();
        product.price    = Number(req.body.price);
        product.category = req.body.category.trim();
        product.rating   = Number(req.body.rating);
        product.stock    = Number(req.body.stock);

        // Image: only replace if a new file was uploaded
        if (req.file) {
            product.image = "/uploads/" + req.file.filename;
        }

        await product.save();
        res.redirect("/admin");
    } catch (error) {
        console.log("Update Product Error:", error);
        res.status(500).send("Server error while updating product");
    }
});

// =================================================
// POST /admin/products/:id/delete — Delete product
// =================================================
router.post("/products/:id/delete", async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        res.redirect("/admin");
    } catch (error) {
        console.log("Delete Product Error:", error);
        res.status(500).send("Server error while deleting product");
    }
});

module.exports = router;
