// ================================================
// seedAdmin.js — Create default admin user
// ------------------------------------------------
// Run with:  node seedAdmin.js
// ================================================

const mongoose = require("mongoose");
const User     = require("./models/User");

// Use the same MongoDB Atlas connection as server.js
const MONGO_URI = "mongodb://sp24bcs038_db_user:Fiza12345@ac-rmzc9nu-shard-00-00.rrc7fpq.mongodb.net:27017,ac-rmzc9nu-shard-00-01.rrc7fpq.mongodb.net:27017,ac-rmzc9nu-shard-00-02.rrc7fpq.mongodb.net:27017/havenlyDB?ssl=true&replicaSet=atlas-uw4sqk-shard-0&authSource=admin&appName=Cluster0";

const ADMIN_EMAIL    = "admin@havenly.com";
const ADMIN_PASSWORD = "admin123";
const ADMIN_NAME     = "Site Admin";

async function seedAdmin() {
    try {
        await mongoose.connect(MONGO_URI);
        console.log("MongoDB Connected for Admin Seeding");

        const existing = await User.findOne({ email: ADMIN_EMAIL });

        if (existing) {
            console.log("Admin user already exists — no changes made.");
            console.log("  Email:", existing.email);
            console.log("  Role: ", existing.role);
        } else {
            // Password will be hashed by the User model's pre-save middleware
            const admin = new User({
                name:     ADMIN_NAME,
                email:    ADMIN_EMAIL,
                password: ADMIN_PASSWORD,
                role:     "admin"
            });
            await admin.save();
            console.log("Admin user created successfully");
            console.log("  Email:    " + ADMIN_EMAIL);
            console.log("  Password: " + ADMIN_PASSWORD);
        }
    } catch (error) {
        console.log("Admin Seeding Error:", error);
    } finally {
        await mongoose.connection.close();
        console.log("Database connection closed");
    }
}

seedAdmin();
