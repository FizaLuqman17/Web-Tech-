// ================================================
// server.js — Havenly Express + EJS Application
//   + REST API with JWT (Lab Task 4)
// ================================================

// ── Load environment variables FIRST ─────────────
require("dotenv").config({ quiet: true });

// ── Express Setup ────────────────────────────────
const mongoose    = require("mongoose");
const express     = require("express");
const path        = require("path");
const session     = require("express-session");
const MongoStore  = require("connect-mongo").default;
const flash       = require("connect-flash");

const app  = express();
const PORT = process.env.PORT || 5000;

// ── MongoDB Atlas Connection ─────────────────────
// Falls back to the original hardcoded URI so it still runs
// if .env is missing for any reason.
const MONGO_URI = process.env.MONGO_URI || "mongodb://sp24bcs038_db_user:Fiza12345@ac-rmzc9nu-shard-00-00.rrc7fpq.mongodb.net:27017,ac-rmzc9nu-shard-00-01.rrc7fpq.mongodb.net:27017,ac-rmzc9nu-shard-00-02.rrc7fpq.mongodb.net:27017/havenlyDB?ssl=true&replicaSet=atlas-uw4sqk-shard-0&authSource=admin&appName=Cluster0";

mongoose.connect(MONGO_URI)
.then(() => {
    console.log("MongoDB Connected Successfully");
})
.catch((error) => {
    console.log("MongoDB Connection Error:", error);
});

// ── EJS Setup ────────────────────────────────────
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// ─────────────────────────────────────────────────
// Middleware order:
//   1. urlencoded
//   2. json
//   3. session
//   4. flash
//   5. res.locals (currentUser / success / error)
//   6. static folder
//   7. routes
// ─────────────────────────────────────────────────

// 1 & 2. Body parsers
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// 3. Session
app.use(session({
    secret: process.env.SESSION_SECRET || "havenly_secret_key",
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
        mongoUrl: MONGO_URI
    }),
    cookie: {
        maxAge: 1000 * 60 * 60 * 24 // 1 day
    }
}));

// 4. Flash messages
app.use(flash());

// 5. Global view locals
app.use((req, res, next) => {
    res.locals.currentUser = req.session.user || null;
    res.locals.success     = req.flash("success");
    res.locals.error       = req.flash("error");
    next();
});

// 6. Static public folder
app.use(express.static(path.join(__dirname, "public")));

// =================================================
// 7. ROUTES
// =================================================

// ── Homepage Route ────────────────────────────────
app.get("/", (req, res) => {
    res.render("homepage");
});

// ── REST API Routes (Lab Task 4) ──────────────────
// Mounted BEFORE the website auth route so /api/* never
// gets caught by anything else. JSON-only responses.
const authApiRoutes    = require("./routes/api/authApi");
const productApiRoutes = require("./routes/api/productApi");
const userApiRoutes    = require("./routes/api/userApi");
const orderApiRoutes   = require("./routes/api/orderApi");

app.use("/api/v1/auth",     authApiRoutes);
app.use("/api/v1/products", productApiRoutes);
app.use("/api/v1/user",     userApiRoutes);
app.use("/api/v1/orders",   orderApiRoutes);

// ── On-Sale Products Route (Lab Exam) ────────────
// GET /onsale-products — renders all isOnSale:true items;
// jQuery paginates them client-side (10 per page).
const onsaleRoutes = require("./routes/onsale");
app.use("/", onsaleRoutes);

// ── Auth + User Routes (Lab Task 3) ──────────────
// /register, /login, /logout, /profile, /checkout
const authRoutes = require("./routes/auth");
app.use("/", authRoutes);

// ── Products Route (Assignment 3) ─────────────────
const productsRoute = require("./routes/products");
app.use("/products", productsRoute);

// ── Admin Route (Assignment 4 — protected by isAdmin) ──
const adminRoute = require("./routes/admin");
app.use("/admin", adminRoute);

// ── Server Start ──────────────────────────────────
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
