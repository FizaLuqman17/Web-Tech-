// ================================================
// routes/onsale.js — On-Sale Products Page (Lab Exam)
// ------------------------------------------------
// GET /onsale-products
// Fetches ALL products where isOnSale: true and renders
// them into views/onsale.ejs. The frontend uses jQuery
// to paginate (10 per page) — NO server-side pagination,
// NO API calls during paging.
// ================================================

const express = require("express");
const router  = express.Router();
const Product = require("../models/Product");

// =================================================
// GET /onsale-products
// =================================================
router.get("/onsale-products", async (req, res) => {
    try {
        // One Mongoose query — fetch all matching products at once
        const onSaleProducts = await Product.find({ isOnSale: true });

        res.render("onsale", {
            title:    "On Sale Products",
            products: onSaleProducts
        });
    } catch (error) {
        console.log("On-Sale Route Error:", error);
        res.status(500).send("Server Error while loading on-sale products");
    }
});

module.exports = router;
