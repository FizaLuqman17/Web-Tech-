// ================================================
// models/Product.js — Mongoose Product Schema
// ================================================

const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    rating: {
        type: Number,
        default: 0
    },
    stock: {
        type: Number,
        default: 0
    },
    image: {
        type: String,
        required: true
    },
    // ── Lab Exam: On-Sale fields ─────────────────
    isOnSale: {
        type: Boolean,
        default: false
    },
    salePrice: {
        type: Number
    }
});

module.exports = mongoose.model("Product", productSchema);
