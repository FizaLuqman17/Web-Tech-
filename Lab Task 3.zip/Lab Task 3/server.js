// ================================================
// server.js — Havenly Express + EJS Application
// ================================================

// ── Express Setup ────────────────────────────────
const mongoose    = require("mongoose");
const express     = require("express");
const path        = require("path");
const session     = require("express-session");
const MongoStore = require("connect-mongo").default;
const flash       = require("connect-flash");

const app  = express();
const PORT = 5000;

// ── MongoDB Atlas Connection ─────────────────────
const MONGO_URI = "mongodb://sp24bcs038_db_user:<db_password>@ac-rmzc9nu-shard-00-00.rrc7fpq.mongodb.net:27017,ac-rmzc9nu-shard-00-01.rrc7fpq.mongodb.net:27017,ac-rmzc9nu-shard-00-02.rrc7fpq.mongodb.net:27017/havenlyDB?ssl=true&replicaSet=atlas-uw4sqk-shard-0&authSource=admin&appName=Cluster0";

mongoose.connect(MONGO_URI)
.then(() => {
    console.log("MongoDB Connected Successfully");
})
.catch((error) => {
    console.log("MongoDB Connection Error:", error);
});

// ── EJS Setup ────────────────────────────────────
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// ─────────────────────────────────────────────────
// Middleware order (per Lab Task 3 spec):
//   1. urlencoded
//   2. json
//   3. session
//   4. flash
//   5. res.locals (currentUser / success / error)
//   6. static folder
//   7. routes
// ─────────────────────────────────────────────────

// 1 & 2. Body parsers (BEFORE session and routes)
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// 3. Session — uses same MongoDB connection string (Lab Task 3)
app.use(session({
    secret: "havenly_secret_key",
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
        mongoUrl: MONGO_URI
    }),
    cookie: {
        maxAge: 1000 * 60 * 60 * 24 // 1 day
    }
}));

// 4. Flash messages
app.use(flash());

// 5. Global view locals — every view can use currentUser/success/error
app.use((req, res, next) => {
    res.locals.currentUser = req.session.user || null;
    res.locals.success     = req.flash("success");
    res.locals.error       = req.flash("error");
    next();
});

// 6. Static public folder
app.use(express.static(path.join(__dirname, "public")));

// 7. Routes
// ── Homepage Route ────────────────────────────────
app.get("/", (req, res) => {
    res.render("homepage");
});

// ── Auth + User Routes (Lab Task 3) ──────────────
// /register, /login, /logout, /profile, /checkout
const authRoutes = require("./routes/auth");
app.use("/", authRoutes);

// ── Products Route (Assignment 3) ─────────────────
const productsRoute = require("./routes/products");
app.use("/products", productsRoute);

// ── Admin Route (Assignment 4 — now protected by isAdmin) ──
const adminRoute = require("./routes/admin");
app.use("/admin", adminRoute);

// ── Server Start ──────────────────────────────────
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
