// ================================================
// routes/auth.js — Authentication + User Routes
// ------------------------------------------------
// Handles: /register, /login, /logout, /profile, /checkout
// ================================================

const express = require("express");
const router  = express.Router();
const User    = require("../models/User");
const { isLoggedIn } = require("../middleware/authMiddleware");

// =================================================
// GET /register — show registration page
// =================================================
router.get("/register", (req, res) => {
    if (req.session.user) return res.redirect("/");
    res.render("auth/register", {
        formData: { name: "", email: "" }
    });
});

// =================================================
// POST /register — create new customer account
// =================================================
router.post("/register", async (req, res) => {
    try {
        const name     = (req.body.name  || "").trim();
        const email    = (req.body.email || "").trim().toLowerCase();
        const password = req.body.password || "";

        // Validation
        if (!name || !email || !password) {
            req.flash("error", "All fields are required.");
            return res.redirect("/register");
        }
        if (password.length < 6) {
            req.flash("error", "Password must be at least 6 characters.");
            return res.redirect("/register");
        }

        // Email uniqueness
        const existing = await User.findOne({ email });
        if (existing) {
            req.flash("error", "Email already exists.");
            return res.redirect("/register");
        }

        // Create user — password gets hashed automatically by pre-save middleware
        const user = new User({ name, email, password, role: "customer" });
        await user.save();

        req.flash("success", "Registration successful. Please login.");
        res.redirect("/login");
    } catch (error) {
        console.log("Register Error:", error);
        if (error.code === 11000) {
            req.flash("error", "Email already exists.");
            return res.redirect("/register");
        }
        req.flash("error", "Something went wrong. Please try again.");
        res.redirect("/register");
    }
});

// =================================================
// GET /login — show login page
// =================================================
router.get("/login", (req, res) => {
    if (req.session.user) return res.redirect("/");
    res.render("auth/login", {
        formData: { email: "" }
    });
});

// =================================================
// POST /login — authenticate and start session
// =================================================
router.post("/login", async (req, res) => {
    try {
        const email    = (req.body.email || "").trim().toLowerCase();
        const password = req.body.password || "";

        if (!email || !password) {
            req.flash("error", "Email and password are required.");
            return res.redirect("/login");
        }

        const user = await User.findOne({ email });
        if (!user) {
            req.flash("error", "Invalid email or password.");
            return res.redirect("/login");
        }

        const ok = await user.comparePassword(password);
        if (!ok) {
            req.flash("error", "Invalid email or password.");
            return res.redirect("/login");
        }

        // Store user info in session
        req.session.user = {
            id:    user._id,
            name:  user.name,
            email: user.email,
            role:  user.role
        };

        req.flash("success", "Welcome back, " + user.name + "!");

        // Role-based redirect
        if (user.role === "admin") {
            return res.redirect("/admin");
        }
        return res.redirect("/");
    } catch (error) {
        console.log("Login Error:", error);
        req.flash("error", "Something went wrong. Please try again.");
        res.redirect("/login");
    }
});

// =================================================
// GET /logout — destroy session
// =================================================
router.get("/logout", (req, res) => {
    if (!req.session) return res.redirect("/");

    req.session.destroy(function (err) {
        if (err) {
            console.log("Logout Error:", err);
            return res.redirect("/");
        }
        res.clearCookie("connect.sid");
        // We can't flash after destroy (no session), so the homepage just shows nothing
        res.redirect("/");
    });
});

// =================================================
// GET /profile — protected
// =================================================
router.get("/profile", isLoggedIn, (req, res) => {
    res.render("profile");
});

// =================================================
// GET /checkout — protected
// =================================================
router.get("/checkout", isLoggedIn, (req, res) => {
    res.render("checkout");
});

module.exports = router;
