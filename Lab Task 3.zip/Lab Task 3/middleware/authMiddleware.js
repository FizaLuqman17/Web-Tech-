// ================================================
// middleware/authMiddleware.js — Route Protection
// ================================================

function isLoggedIn(req, res, next) {
    if (req.session && req.session.user) {
        return next();
    }
    req.flash("error", "Please login first.");
    return res.redirect("/login");
}

function isAdmin(req, res, next) {
    if (req.session && req.session.user && req.session.user.role === "admin") {
        return next();
    }
    req.flash("error", "Access denied. Admins only.");
    return res.redirect("/");
}

module.exports = {
    isLoggedIn,
    isAdmin
};
