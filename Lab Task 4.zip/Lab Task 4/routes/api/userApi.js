// ================================================
// routes/api/userApi.js — Authenticated User API
// ------------------------------------------------
// GET /api/v1/user/profile   (JWT required)
// ================================================

const express     = require("express");
const router      = express.Router();
const User        = require("../../models/User");
const verifyToken = require("../../middleware/verifyToken");

// =================================================
// GET /api/v1/user/profile
// Returns the authenticated user (no password)
// =================================================
router.get("/profile", verifyToken, async (req, res) => {
    try {
        // Fetch fresh from DB, exclude password
        const user = await User.findById(req.user.user_id).select("-password").lean();

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }

        return res.status(200).json({
            success: true,
            user: {
                id:    user._id,
                name:  user.name,
                email: user.email,
                role:  user.role
            }
        });
    } catch (error) {
        console.log("User API profile error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
});

module.exports = router;
