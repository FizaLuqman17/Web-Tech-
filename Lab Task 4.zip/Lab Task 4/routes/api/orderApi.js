// ================================================
// routes/api/orderApi.js — Order API (JWT protected)
// ------------------------------------------------
// POST /api/v1/orders        — create order
// GET  /api/v1/orders        — list authenticated user's orders
// ================================================

const express     = require("express");
const router      = express.Router();
const Order       = require("../../models/Order");
const verifyToken = require("../../middleware/verifyToken");

// All order routes require a valid JWT
router.use(verifyToken);

// =================================================
// POST /api/v1/orders
// Body:
//   {
//     "products": [ { "product": "<id>", "quantity": 2 } ],
//     "totalAmount": 50000
//   }
// =================================================
router.post("/", async (req, res) => {
    try {
        const { products, totalAmount } = req.body || {};

        // Validation
        if (!Array.isArray(products) || products.length === 0) {
            return res.status(400).json({
                success: false,
                message: "Products array is required and must not be empty"
            });
        }

        for (const item of products) {
            if (!item || !item.product || !item.quantity || Number(item.quantity) < 1) {
                return res.status(400).json({
                    success: false,
                    message: "Each product entry must include a product id and quantity >= 1"
                });
            }
        }

        if (totalAmount === undefined || totalAmount === null || isNaN(Number(totalAmount)) || Number(totalAmount) < 0) {
            return res.status(400).json({
                success: false,
                message: "totalAmount is required and must be a non-negative number"
            });
        }

        const order = await Order.create({
            user:        req.user.user_id,
            products:    products.map(p => ({ product: p.product, quantity: Number(p.quantity) })),
            totalAmount: Number(totalAmount),
            status:      "pending"
        });

        return res.status(201).json({
            success: true,
            message: "Order created successfully",
            order
        });
    } catch (error) {
        console.log("Order API create error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
});

// =================================================
// GET /api/v1/orders
// Returns the authenticated user's orders.
// =================================================
router.get("/", async (req, res) => {
    try {
        const orders = await Order.find({ user: req.user.user_id })
            .sort({ createdAt: -1 })
            .lean();

        return res.status(200).json({
            success: true,
            count: orders.length,
            orders
        });
    } catch (error) {
        console.log("Order API list error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
});

module.exports = router;
