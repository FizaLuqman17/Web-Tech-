// ================================================
// routes/api/productApi.js — Public Product API
// ------------------------------------------------
// GET /api/v1/products       — paginated, filterable list
// GET /api/v1/products/:id   — single product by id
// ================================================

const express  = require("express");
const mongoose = require("mongoose");
const router   = express.Router();
const Product  = require("../../models/Product");

// =================================================
// GET /api/v1/products
// Reuses the same filter/search/sort/pagination
// logic as the EJS /products route.
// =================================================
router.get("/", async (req, res) => {
    try {
        // ── Read query params ────────────────────
        const search   = req.query.search   || "";
        const category = req.query.category || "";
        const minPrice = req.query.minPrice || "";
        const maxPrice = req.query.maxPrice || "";
        const sort     = req.query.sort     || "";

        // ── Build the Mongoose query ────────────
        const query = {};

        if (search) {
            query.name = { $regex: search, $options: "i" };
        }
        if (category) {
            query.category = category;
        }
        if (minPrice || maxPrice) {
            query.price = {};
            if (minPrice) query.price.$gte = Number(minPrice);
            if (maxPrice) query.price.$lte = Number(maxPrice);
        }

        // ── Sorting ──────────────────────────────
        let sortOption = {};
        if (sort === "priceAsc")   sortOption.price  =  1;
        if (sort === "priceDesc")  sortOption.price  = -1;
        if (sort === "ratingDesc") sortOption.rating = -1;

        // ── Pagination ───────────────────────────
        const limit = 8;
        const page  = parseInt(req.query.page) || 1;
        const skip  = (page - 1) * limit;

        const totalProducts = await Product.countDocuments(query);
        const totalPages    = Math.ceil(totalProducts / limit);

        const products = await Product.find(query)
            .sort(sortOption)
            .skip(skip)
            .limit(limit)
            .lean();

        return res.status(200).json({
            success: true,
            currentPage: page,
            totalPages,
            totalProducts,
            products
        });
    } catch (error) {
        console.log("Product API list error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
});

// =================================================
// GET /api/v1/products/:id
// =================================================
router.get("/:id", async (req, res) => {
    try {
        const { id } = req.params;

        // Defensive: reject invalid Mongo ObjectIds with a clean 404
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }

        const product = await Product.findById(id).lean();

        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }

        return res.status(200).json({
            success: true,
            product
        });
    } catch (error) {
        console.log("Product API detail error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
});

module.exports = router;
