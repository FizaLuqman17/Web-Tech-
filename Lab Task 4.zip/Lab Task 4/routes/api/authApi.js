// ================================================
// routes/api/authApi.js — JWT Auth API
// ------------------------------------------------
// POST /api/v1/auth/login   — authenticate and issue JWT
// ================================================

const express = require("express");
const jwt     = require("jsonwebtoken");
const router  = express.Router();
const User    = require("../../models/User");

// =================================================
// POST /api/v1/auth/login
// Body: { email, password }
// Returns: { success, token, user }
// =================================================
router.post("/login", async (req, res) => {
    try {
        const email    = (req.body.email || "").trim().toLowerCase();
        const password = req.body.password || "";

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: "Email and password are required"
            });
        }

        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            });
        }

        const ok = await user.comparePassword(password);
        if (!ok) {
            return res.status(401).json({
                success: false,
                message: "Invalid email or password"
            });
        }

        // Sign JWT
        const token = jwt.sign(
            {
                user_id: user._id,
                role:    user.role
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES_IN || "1h" }
        );

        return res.status(200).json({
            success: true,
            token,
            user: {
                id:    user._id,
                name:  user.name,
                email: user.email,
                role:  user.role
            }
        });
    } catch (error) {
        console.log("Auth API login error:", error);
        return res.status(500).json({
            success: false,
            message: "Server error"
        });
    }
});

module.exports = router;
