// ================================================
// middleware/verifyToken.js — JWT Verification
// ------------------------------------------------
// Expects header:  Authorization: Bearer <token>
// On success, attaches decoded payload to req.user
// ================================================

const jwt = require("jsonwebtoken");

function verifyToken(req, res, next) {
    const authHeader = req.headers.authorization || req.headers.Authorization;

    // 1. Missing or wrong format → 401
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            success: false,
            message: "Unauthorized"
        });
    }

    // 2. Extract the token
    const token = authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Unauthorized"
        });
    }

    // 3. Verify
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; // { user_id, role, iat, exp }
        return next();
    } catch (err) {
        // Expired or invalid → 403
        return res.status(403).json({
            success: false,
            message: "Invalid or expired token"
        });
    }
}

module.exports = verifyToken;
